<?php

/**
 * stub class representing AMQPException from pecl-amqp
 */
class AMQPException extends Exception
{
}
