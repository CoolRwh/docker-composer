
extern zend_class_entry *phalcon_acl_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Acl_Exception);

