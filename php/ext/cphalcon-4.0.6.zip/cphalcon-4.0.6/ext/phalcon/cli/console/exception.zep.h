
extern zend_class_entry *phalcon_cli_console_exception_ce;

ZEPHIR_INIT_CLASS(Phalcon_Cli_Console_Exception);

