<?php
go(function () {

	var_dump(co::exec("ls /"));
});
