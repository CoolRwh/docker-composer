<?php 
/**
 * @generate-legacy-arginfo
 * @generate-function-entries
 */
function swoole_get_objects() : array|bool {
    
}

function swoole_get_vm_status() : array|bool {
    
}

function swoole_get_object_by_handle(int $handle): object|bool {
    
}
